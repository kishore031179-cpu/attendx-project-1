export type AttendanceStatus = "present" | "absent" | "late";

export interface AttendanceRecord {
  date: string;
  status: AttendanceStatus;
}

export interface Student {
  id: number;
  rollNumber: string;
  name: string;
  email: string;
  attendancePercentage: number;
  totalClasses: number;
  attendedClasses: number;
  lastAttendance: string;
  history: AttendanceRecord[];
  todayStatus: AttendanceStatus | null;
}

function generateHistory(attended: number, total: number): AttendanceRecord[] {
  const records: AttendanceRecord[] = [];
  const today = new Date();
  let attendedCount = 0;

  for (let i = total - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i - 1);
    const dayOfWeek = date.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;

    const dateStr = date.toISOString().split("T")[0];
    const remaining = total - records.length;
    const remainingNeeded = attended - attendedCount;
    const rand = Math.random();

    let status: AttendanceStatus;
    if (remainingNeeded <= 0) {
      status = "absent";
    } else if (remaining <= remainingNeeded) {
      status = rand > 0.1 ? "present" : "late";
    } else {
      const prob = remainingNeeded / remaining;
      if (rand < prob * 0.85) status = "present";
      else if (rand < prob) status = "late";
      else status = "absent";
    }

    if (status === "present" || status === "late") attendedCount++;
    records.push({ date: dateStr, status });
  }

  return records;
}

const firstNames = [
  "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayaan",
  "Krishna", "Ishaan", "Shaurya", "Atharva", "Advik", "Pranav", "Dhruv",
  "Kabir", "Ritvik", "Aarush", "Rohan", "Yash", "Ananya", "Saanvi", "Aanya",
  "Diya", "Aarohi", "Kavya", "Riya", "Aishwarya", "Nisha", "Pooja",
  "Shreya", "Tanvi", "Priya", "Meghna", "Divya", "Neha", "Swati", "Lakshmi",
  "Puja", "Sonal", "Aryan", "Dev", "Nikhil", "Rahul", "Karan", "Akash",
  "Mohit", "Vikram", "Harsh", "Ravi", "Gaurav", "Kunal", "Siddharth", "Amit",
  "Tushar", "Varun", "Manish", "Rajesh", "Deepak", "Manoj", "Suresh",
  "Sumit", "Ankur", "Neeraj", "Sachin",
];

const lastNames = [
  "Sharma", "Verma", "Singh", "Kumar", "Patel", "Gupta", "Yadav", "Joshi",
  "Mishra", "Tiwari", "Pandey", "Agarwal", "Mehta", "Shah", "Chopra",
  "Malhotra", "Kapoor", "Rao", "Nair", "Iyer", "Pillai", "Menon", "Reddy",
  "Naidu", "Das",
];

export function generateStudents(): Student[] {
  const students: Student[] = [];
  const totalClasses = 60;

  for (let i = 0; i < 65; i++) {
    const firstName = firstNames[i];
    const lastName = lastNames[i % lastNames.length];
    const name = `${firstName} ${lastName}`;
    const rollNumber = `CS${String(i + 1).padStart(3, "0")}`;

    let attendedClasses: number;
    if (i < 5) attendedClasses = Math.floor(Math.random() * 6) + 2; // very low: <15%
    else if (i < 15) attendedClasses = Math.floor(Math.random() * 12) + 15; // low: 25-45%
    else if (i < 30) attendedClasses = Math.floor(Math.random() * 10) + 33; // borderline: 55-72%
    else attendedClasses = Math.floor(Math.random() * 12) + 48; // good: 80-100%

    attendedClasses = Math.min(attendedClasses, totalClasses);
    const attendancePercentage = Math.round((attendedClasses / totalClasses) * 100);

    const history = generateHistory(attendedClasses, totalClasses);
    const lastPresentRecord = [...history].reverse().find(
      (r) => r.status === "present" || r.status === "late"
    );

    const statuses: (AttendanceStatus | null)[] = ["present", "present", "present", "late", "absent", null];
    const todayStatus = statuses[Math.floor(Math.random() * statuses.length)];

    students.push({
      id: i + 1,
      rollNumber,
      name,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@college.edu`,
      attendancePercentage,
      totalClasses,
      attendedClasses,
      lastAttendance: lastPresentRecord?.date ?? "N/A",
      history,
      todayStatus,
    });
  }

  return students.sort((a, b) => a.rollNumber.localeCompare(b.rollNumber));
}

export const STUDENTS = generateStudents();

export function getAttendanceColor(percentage: number): string {
  if (percentage >= 85) return "text-emerald-400";
  if (percentage >= 75) return "text-yellow-400";
  if (percentage >= 60) return "text-orange-400";
  return "text-red-400";
}

export function getAttendanceBgColor(percentage: number): string {
  if (percentage >= 85) return "bg-emerald-500";
  if (percentage >= 75) return "bg-yellow-500";
  if (percentage >= 60) return "bg-orange-500";
  return "bg-red-500";
}

export function getAttendanceStroke(percentage: number): string {
  if (percentage >= 85) return "#10b981";
  if (percentage >= 75) return "#eab308";
  if (percentage >= 60) return "#f97316";
  return "#ef4444";
}

export function getDailyTrend() {
  const days = [];
  const today = new Date();
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);
    const dayOfWeek = date.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) continue;
    const label = date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const attendance = Math.floor(Math.random() * 15) + 50;
    days.push({ date: label, attendance, absent: 65 - attendance });
  }
  return days.slice(-20);
}

export function getWeeklyData() {
  const weeks = [];
  for (let i = 7; i >= 1; i--) {
    weeks.push({
      week: `Week ${8 - i}`,
      present: Math.floor(Math.random() * 10) + 52,
      absent: Math.floor(Math.random() * 8) + 5,
      late: Math.floor(Math.random() * 5) + 2,
    });
  }
  return weeks;
}
