"use client";

import { useState } from "react";
import { Search, CheckCircle, XCircle, Clock, User } from "lucide-react";
import type { Student } from "@/lib/student-data";
import { getAttendanceColor, getAttendanceStroke } from "@/lib/student-data";
import StudentDetailModal from "./StudentDetailModal";

interface Props {
  students: Student[];
}

export default function StudentCards({ students }: Props) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Student | null>(null);

  const filtered = students.filter((s) => {
    const q = search.toLowerCase();
    return !q || s.name.toLowerCase().includes(q) || s.rollNumber.toLowerCase().includes(q);
  });

  return (
    <div>
      <div className="mb-5 relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search students..."
          className="w-full pl-9 pr-4 py-2 text-sm bg-secondary border border-border/60 rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {filtered.map((student, i) => (
          <StudentCard
            key={student.id}
            student={student}
            index={i}
            onClick={() => setSelected(student)}
          />
        ))}
      </div>

      {selected && <StudentDetailModal student={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function StudentCard({ student, index, onClick }: { student: Student; index: number; onClick: () => void }) {
  const radius = 32;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (student.attendancePercentage / 100) * circumference;
  const stroke = getAttendanceStroke(student.attendancePercentage);
  const colorClass = getAttendanceColor(student.attendancePercentage);

  const statusConfig = {
    present: { icon: CheckCircle, color: "#10b981", label: "P" },
    absent: { icon: XCircle, color: "#ef4444", label: "A" },
    late: { icon: Clock, color: "#f59e0b", label: "L" },
  };
  const todayCfg = student.todayStatus ? statusConfig[student.todayStatus] : null;

  return (
    <div
      className="group relative bg-card border border-border/60 rounded-2xl p-4 cursor-pointer hover:border-primary/40 hover:-translate-y-1 hover:shadow-xl transition-all duration-300 animate-fade-up"
      style={{ animationDelay: `${(index % 24) * 25}ms`, animationFillMode: "both" }}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && onClick()}
      aria-label={`View ${student.name}'s details`}
    >
      {/* Today badge */}
      {todayCfg && (
        <div
          className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
          style={{ background: `${todayCfg.color}20`, color: todayCfg.color, border: `1px solid ${todayCfg.color}40` }}
          title={student.todayStatus ?? ""}
        >
          {todayCfg.label}
        </div>
      )}

      {/* Ring */}
      <div className="flex justify-center mb-3">
        <div className="relative">
          <svg width="80" height="80" className="-rotate-90">
            <circle cx="40" cy="40" r={radius} fill="none" stroke="currentColor" strokeWidth="5" className="text-secondary" />
            <circle
              cx="40" cy="40" r={radius}
              fill="none"
              stroke={stroke}
              strokeWidth="5"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              className="animate-ring"
              style={{ filter: `drop-shadow(0 0 4px ${stroke})`, transition: "stroke-dashoffset 1s ease" }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center text-sm font-semibold text-indigo-300">
              {student.name.charAt(0)}
            </div>
          </div>
        </div>
      </div>

      <div className="text-center">
        <div className={`text-lg font-bold ${colorClass}`}>{student.attendancePercentage}%</div>
        <div className="text-xs font-semibold text-foreground mt-0.5 truncate">{student.name}</div>
        <div className="text-xs text-muted-foreground font-mono">{student.rollNumber}</div>
      </div>

      {/* Quick action */}
      <div className="mt-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <button
          className="flex-1 py-1 text-xs rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/20 transition-all"
          onClick={(e) => { e.stopPropagation(); }}
        >
          P
        </button>
        <button
          className="flex-1 py-1 text-xs rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 border border-red-500/20 transition-all"
          onClick={(e) => { e.stopPropagation(); }}
        >
          A
        </button>
        <button
          className="flex-1 py-1 text-xs rounded-lg bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25 border border-yellow-500/20 transition-all"
          onClick={(e) => { e.stopPropagation(); }}
        >
          L
        </button>
      </div>
    </div>
  );
}
