"use client";

import { useEffect, useRef } from "react";
import { X, Mail, Hash, TrendingUp, Calendar, CheckCircle, XCircle, Clock } from "lucide-react";
import type { Student } from "@/lib/student-data";
import { getAttendanceColor, getAttendanceStroke } from "@/lib/student-data";
import AttendanceHeatmap from "./AttendanceHeatmap";

interface Props {
  student: Student;
  onClose: () => void;
}

export default function StudentDetailModal({ student, onClose }: Props) {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const presentCount = student.history.filter((h) => h.status === "present").length;
  const absentCount = student.history.filter((h) => h.status === "absent").length;
  const lateCount = student.history.filter((h) => h.status === "late").length;

  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (student.attendancePercentage / 100) * circumference;
  const stroke = getAttendanceStroke(student.attendancePercentage);

  const recentHistory = [...student.history].reverse().slice(0, 20);

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }}
      onClick={(e) => { if (e.target === overlayRef.current) onClose(); }}
    >
      <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-card border border-border rounded-2xl animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border/60">
          <div className="flex items-center gap-4">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl font-bold text-white"
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}
            >
              {student.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">{student.name}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Hash className="w-3 h-3" /> {student.rollNumber}
                </span>
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Mail className="w-3 h-3" /> {student.email}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Ring + stats */}
          <div className="flex flex-col items-center gap-6">
            <div className="relative flex items-center justify-center">
              <svg width="120" height="120" className="-rotate-90">
                <circle cx="60" cy="60" r={radius} fill="none" stroke="currentColor" strokeWidth="8" className="text-secondary" />
                <circle
                  cx="60" cy="60" r={radius}
                  fill="none"
                  stroke={stroke}
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={offset}
                  className="animate-ring"
                  style={{ filter: `drop-shadow(0 0 6px ${stroke})` }}
                />
              </svg>
              <div className="absolute text-center">
                <div className={`text-2xl font-bold ${getAttendanceColor(student.attendancePercentage)}`}>
                  {student.attendancePercentage}%
                </div>
                <div className="text-xs text-muted-foreground">attendance</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 w-full">
              {[
                { label: "Present", value: presentCount, icon: CheckCircle, color: "#10b981" },
                { label: "Absent", value: absentCount, icon: XCircle, color: "#ef4444" },
                { label: "Late", value: lateCount, icon: Clock, color: "#f59e0b" },
              ].map((stat) => (
                <div key={stat.label} className="bg-secondary rounded-xl p-3 text-center border border-border/60">
                  <stat.icon className="w-4 h-4 mx-auto mb-1" style={{ color: stat.color }} />
                  <div className="text-xl font-bold text-foreground">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="w-full bg-secondary rounded-xl p-4 border border-border/60">
              <div className="flex items-center gap-2 mb-2 text-sm font-medium text-foreground">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                Key Info
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total Classes</span>
                  <span className="text-foreground font-medium">{student.totalClasses}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Attended</span>
                  <span className="text-foreground font-medium">{student.attendedClasses}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Present</span>
                  <span className="text-foreground font-medium">{student.lastAttendance}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Heatmap + timeline */}
          <div className="flex flex-col gap-4">
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">Attendance Heatmap</h3>
              <AttendanceHeatmap history={student.history} compact />
            </div>

            <div>
              <h3 className="text-sm font-semibold text-foreground mb-3">Recent Activity</h3>
              <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                {recentHistory.map((record) => {
                  const cfg = {
                    present: { color: "#10b981", icon: CheckCircle, label: "Present" },
                    absent: { color: "#ef4444", icon: XCircle, label: "Absent" },
                    late: { color: "#f59e0b", icon: Clock, label: "Late" },
                  }[record.status];
                  return (
                    <div
                      key={record.date}
                      className="flex items-center gap-3 px-3 py-2 rounded-lg bg-secondary/50 border border-border/40"
                    >
                      <cfg.icon className="w-3.5 h-3.5 shrink-0" style={{ color: cfg.color }} />
                      <span className="text-xs text-muted-foreground flex-1">{record.date}</span>
                      <span
                        className="text-xs font-medium px-2 py-0.5 rounded-full"
                        style={{ background: `${cfg.color}18`, color: cfg.color }}
                      >
                        {cfg.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
