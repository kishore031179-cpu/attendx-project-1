"use client";

import { GraduationCap, Bell, Settings, Users, TrendingUp, Calendar } from "lucide-react";

interface HeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  totalPresent: number;
  totalAbsent: number;
}

const tabs = [
  { id: "overview", label: "Overview", icon: TrendingUp },
  { id: "students", label: "Students", icon: Users },
  { id: "analytics", label: "Analytics", icon: TrendingUp },
  { id: "attendance", label: "Mark Attendance", icon: Calendar },
];

export default function Header({ activeTab, onTabChange, totalPresent, totalAbsent }: HeaderProps) {
  const attendanceRate = Math.round((totalPresent / 65) * 100);

  return (
    <header className="sticky top-0 z-50 border-b border-border/50 backdrop-blur-xl bg-background/80">
      {/* Gradient bar */}
      <div
        className="h-1 w-full animate-gradient-x"
        style={{
          background: "linear-gradient(90deg, #6366f1, #8b5cf6, #06b6d4, #6366f1)",
        }}
      />

      <div className="max-w-screen-2xl mx-auto px-6">
        {/* Top row */}
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}
            >
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">AttendX</h1>
              <p className="text-xs text-muted-foreground">CS Batch 2024 · Semester IV</p>
            </div>
          </div>

          {/* Quick stats */}
          <div className="hidden md:flex items-center gap-6">
            <StatPill label="Present Today" value={`${totalPresent}`} color="#10b981" />
            <StatPill label="Absent Today" value={`${totalAbsent}`} color="#ef4444" />
            <StatPill label="Attendance Rate" value={`${attendanceRate}%`} color="#6366f1" />
          </div>

          <div className="flex items-center gap-2">
            <button className="w-9 h-9 rounded-lg border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-all">
              <Bell className="w-4 h-4" />
            </button>
            <button className="w-9 h-9 rounded-lg border border-border/60 flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-all">
              <Settings className="w-4 h-4" />
            </button>
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-semibold">
              P
            </div>
          </div>
        </div>

        {/* Nav tabs */}
        <nav className="flex gap-1 -mb-px">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all rounded-t-lg ${
                  isActive
                    ? "border-primary text-primary bg-primary/5"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
}

function StatPill({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary border border-border/50">
      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
      <span className="text-xs text-muted-foreground">{label}:</span>
      <span className="text-sm font-semibold" style={{ color }}>
        {value}
      </span>
    </div>
  );
}
