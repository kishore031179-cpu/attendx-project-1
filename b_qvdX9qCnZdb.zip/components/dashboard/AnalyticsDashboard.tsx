"use client";

import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { getDailyTrend, getWeeklyData } from "@/lib/student-data";
import type { Student } from "@/lib/student-data";

interface Props {
  students: Student[];
}

const PIE_COLORS = ["#10b981", "#f59e0b", "#ef4444", "#6366f1"];

const dailyData = getDailyTrend();
const weeklyData = getWeeklyData();

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl px-4 py-3 text-sm shadow-xl">
      <p className="font-semibold text-foreground mb-2">{label}</p>
      {payload.map((entry: any) => (
        <div key={entry.name} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
          <span className="text-muted-foreground">{entry.name}:</span>
          <span className="text-foreground font-medium">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function AnalyticsDashboard({ students }: Props) {
  const excellent = students.filter((s) => s.attendancePercentage >= 85).length;
  const good = students.filter((s) => s.attendancePercentage >= 75 && s.attendancePercentage < 85).length;
  const atRisk = students.filter((s) => s.attendancePercentage >= 60 && s.attendancePercentage < 75).length;
  const critical = students.filter((s) => s.attendancePercentage < 60).length;

  const distributionData = [
    { name: "Excellent (≥85%)", value: excellent },
    { name: "Good (75-84%)", value: good },
    { name: "At Risk (60-74%)", value: atRisk },
    { name: "Critical (<60%)", value: critical },
  ];

  const avgWeekly = weeklyData.map((w) => ({
    ...w,
    rate: Math.round((w.present / 65) * 100),
  }));

  return (
    <div className="space-y-6">
      {/* Summary row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Excellent", value: excellent, pct: Math.round((excellent / 65) * 100), color: "#10b981" },
          { label: "Good", value: good, pct: Math.round((good / 65) * 100), color: "#6366f1" },
          { label: "At Risk", value: atRisk, pct: Math.round((atRisk / 65) * 100), color: "#f59e0b" },
          { label: "Critical", value: critical, pct: Math.round((critical / 65) * 100), color: "#ef4444" },
        ].map((item) => (
          <div key={item.label} className="bg-card border border-border/60 rounded-xl p-4 animate-fade-up">
            <div className="flex items-end justify-between mb-3">
              <span className="text-sm text-muted-foreground">{item.label}</span>
              <span className="text-2xl font-bold" style={{ color: item.color }}>{item.value}</span>
            </div>
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-1000"
                style={{ width: `${item.pct}%`, background: item.color }}
              />
            </div>
            <div className="text-xs text-muted-foreground mt-1.5">{item.pct}% of class</div>
          </div>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily trend */}
        <div className="lg:col-span-2 bg-card border border-border/60 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Daily Attendance Trend (Last 20 Working Days)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <YAxis domain={[0, 65]} tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Line
                type="monotone" dataKey="attendance" name="Present"
                stroke="#6366f1" strokeWidth={2} dot={false}
                activeDot={{ r: 4, fill: "#6366f1" }}
              />
              <Line
                type="monotone" dataKey="absent" name="Absent"
                stroke="#ef4444" strokeWidth={2} dot={false}
                activeDot={{ r: 4, fill: "#ef4444" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Distribution pie */}
        <div className="bg-card border border-border/60 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Attendance Distribution</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={distributionData}
                cx="50%" cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {distributionData.map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i]} stroke="transparent" />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {distributionData.map((d, i) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: PIE_COLORS[i] }} />
                  <span className="text-muted-foreground">{d.name}</span>
                </div>
                <span className="text-foreground font-medium">{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly bar */}
        <div className="bg-card border border-border/60 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Weekly Attendance Breakdown</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={weeklyData} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="week" tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="present" name="Present" fill="#10b981" radius={[3, 3, 0, 0]} />
              <Bar dataKey="absent" name="Absent" fill="#ef4444" radius={[3, 3, 0, 0]} />
              <Bar dataKey="late" name="Late" fill="#f59e0b" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Attendance rate line */}
        <div className="bg-card border border-border/60 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Weekly Attendance Rate (%)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={avgWeekly}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="week" tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <YAxis domain={[60, 100]} tick={{ fontSize: 10, fill: "#666" }} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone" dataKey="rate" name="Rate %"
                stroke="#6366f1" strokeWidth={2.5}
                dot={{ r: 4, fill: "#6366f1", strokeWidth: 0 }}
                activeDot={{ r: 5 }}
              />
              {/* Reference line at 75% */}
              <Line
                type="monotone" dataKey={() => 75} name="Min Threshold"
                stroke="#f59e0b" strokeWidth={1.5} strokeDasharray="4 3" dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
