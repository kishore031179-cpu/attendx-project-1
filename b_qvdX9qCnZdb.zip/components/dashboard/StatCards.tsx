"use client";

import { useEffect, useState } from "react";
import { Users, UserCheck, UserX, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import type { Student } from "@/lib/student-data";

interface StatCardsProps {
  students: Student[];
}

export default function StatCards({ students }: StatCardsProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  const total = students.length;
  const avgAttendance = Math.round(students.reduce((s, st) => s + st.attendancePercentage, 0) / total);
  const atRisk = students.filter((s) => s.attendancePercentage < 75).length;
  const critical = students.filter((s) => s.attendancePercentage < 60).length;
  const excellent = students.filter((s) => s.attendancePercentage >= 85).length;
  const presentToday = students.filter((s) => s.todayStatus === "present").length;

  const cards = [
    {
      label: "Total Students",
      value: total,
      sub: "Enrolled this semester",
      icon: Users,
      color: "#6366f1",
      bg: "rgba(99,102,241,0.1)",
      trend: null,
    },
    {
      label: "Present Today",
      value: presentToday,
      sub: `${Math.round((presentToday / total) * 100)}% attendance today`,
      icon: UserCheck,
      color: "#10b981",
      bg: "rgba(16,185,129,0.1)",
      trend: "+3",
    },
    {
      label: "Avg Attendance",
      value: `${avgAttendance}%`,
      sub: "Across all students",
      icon: TrendingUp,
      color: "#06b6d4",
      bg: "rgba(6,182,212,0.1)",
      trend: "+2%",
    },
    {
      label: "At Risk",
      value: atRisk,
      sub: "Below 75% threshold",
      icon: AlertTriangle,
      color: "#f59e0b",
      bg: "rgba(245,158,11,0.1)",
      trend: null,
    },
    {
      label: "Critical",
      value: critical,
      sub: "Below 60% attendance",
      icon: UserX,
      color: "#ef4444",
      bg: "rgba(239,68,68,0.1)",
      trend: null,
    },
    {
      label: "Excellent",
      value: excellent,
      sub: "Above 85% attendance",
      icon: TrendingUp,
      color: "#10b981",
      bg: "rgba(16,185,129,0.1)",
      trend: null,
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {cards.map((card, i) => {
        const Icon = card.icon;
        return (
          <div
            key={card.label}
            className="rounded-xl border border-border/60 p-4 bg-card hover:border-border transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg animate-fade-up"
            style={{
              animationDelay: `${i * 60}ms`,
              animationFillMode: "both",
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center"
                style={{ background: card.bg }}
              >
                <Icon className="w-4 h-4" style={{ color: card.color }} />
              </div>
              {card.trend && (
                <span
                  className="text-xs font-medium px-1.5 py-0.5 rounded-md"
                  style={{ background: "rgba(16,185,129,0.15)", color: "#10b981" }}
                >
                  {card.trend}
                </span>
              )}
            </div>
            <div
              className="text-2xl font-bold mb-0.5"
              style={{ color: mounted ? card.color : "inherit" }}
            >
              {card.value}
            </div>
            <div className="text-xs font-medium text-foreground">{card.label}</div>
            <div className="text-xs text-muted-foreground mt-0.5 leading-tight">{card.sub}</div>
          </div>
        );
      })}
    </div>
  );
}
