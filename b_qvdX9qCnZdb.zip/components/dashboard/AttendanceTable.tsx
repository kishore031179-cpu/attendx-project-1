"use client";

import { useState, useMemo } from "react";
import {
  Search, ChevronUp, ChevronDown, ChevronsUpDown, Eye, CheckCircle,
  XCircle, Clock, Filter, X,
} from "lucide-react";
import type { Student } from "@/lib/student-data";
import { getAttendanceColor, getAttendanceBgColor } from "@/lib/student-data";
import StudentDetailModal from "./StudentDetailModal";

interface AttendanceTableProps {
  students: Student[];
}

type SortField = "name" | "rollNumber" | "attendancePercentage" | "lastAttendance";
type SortDir = "asc" | "desc";
type FilterStatus = "all" | "present" | "absent" | "late";
type FilterRange = "all" | "excellent" | "good" | "at-risk" | "critical";

export default function AttendanceTable({ students }: AttendanceTableProps) {
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<SortField>("rollNumber");
  const [sortDir, setSortDir] = useState<SortDir>("asc");
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");
  const [filterRange, setFilterRange] = useState<FilterRange>("all");
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [page, setPage] = useState(1);
  const pageSize = 15;

  const handleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortField(field); setSortDir("asc"); }
  };

  const filtered = useMemo(() => {
    return students
      .filter((s) => {
        const q = search.toLowerCase();
        if (q && !s.name.toLowerCase().includes(q) && !s.rollNumber.toLowerCase().includes(q)) return false;
        if (filterStatus !== "all" && s.todayStatus !== filterStatus) return false;
        if (filterRange === "excellent" && s.attendancePercentage < 85) return false;
        if (filterRange === "good" && (s.attendancePercentage < 75 || s.attendancePercentage >= 85)) return false;
        if (filterRange === "at-risk" && (s.attendancePercentage < 60 || s.attendancePercentage >= 75)) return false;
        if (filterRange === "critical" && s.attendancePercentage >= 60) return false;
        return true;
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortField === "name") cmp = a.name.localeCompare(b.name);
        else if (sortField === "rollNumber") cmp = a.rollNumber.localeCompare(b.rollNumber);
        else if (sortField === "attendancePercentage") cmp = a.attendancePercentage - b.attendancePercentage;
        else if (sortField === "lastAttendance") cmp = a.lastAttendance.localeCompare(b.lastAttendance);
        return sortDir === "asc" ? cmp : -cmp;
      });
  }, [students, search, sortField, sortDir, filterStatus, filterRange]);

  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);

  const clearFilters = () => {
    setSearch(""); setFilterStatus("all"); setFilterRange("all"); setPage(1);
  };
  const hasFilters = search || filterStatus !== "all" || filterRange !== "all";

  return (
    <div className="rounded-xl border border-border/60 bg-card overflow-hidden">
      {/* Toolbar */}
      <div className="p-4 border-b border-border/60 flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-56">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search by name or roll number..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-secondary border border-border/60 rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <FilterSelect
            label="Status"
            value={filterStatus}
            onChange={(v) => { setFilterStatus(v as FilterStatus); setPage(1); }}
            options={[
              { value: "all", label: "All Status" },
              { value: "present", label: "Present" },
              { value: "absent", label: "Absent" },
              { value: "late", label: "Late" },
            ]}
          />
          <FilterSelect
            label="Range"
            value={filterRange}
            onChange={(v) => { setFilterRange(v as FilterRange); setPage(1); }}
            options={[
              { value: "all", label: "All Ranges" },
              { value: "excellent", label: "≥85% Excellent" },
              { value: "good", label: "75-84% Good" },
              { value: "at-risk", label: "60-74% At Risk" },
              { value: "critical", label: "<60% Critical" },
            ]}
          />
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-1 px-3 py-2 text-xs text-muted-foreground hover:text-foreground border border-border/60 rounded-lg hover:bg-accent transition-all"
            >
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        <span className="text-xs text-muted-foreground ml-auto">
          {filtered.length} of {students.length} students
        </span>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border/60 bg-secondary/50">
              <SortHeader field="rollNumber" current={sortField} dir={sortDir} onClick={handleSort} label="Roll No." />
              <SortHeader field="name" current={sortField} dir={sortDir} onClick={handleSort} label="Student Name" />
              <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Today
              </th>
              <SortHeader field="attendancePercentage" current={sortField} dir={sortDir} onClick={handleSort} label="Attendance" />
              <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Progress
              </th>
              <SortHeader field="lastAttendance" current={sortField} dir={sortDir} onClick={handleSort} label="Last Present" />
              <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Classes
              </th>
              <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {paginated.map((student, i) => (
              <TableRow
                key={student.id}
                student={student}
                index={i}
                onView={() => setSelectedStudent(student)}
              />
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-border/60 bg-secondary/30">
          <span className="text-xs text-muted-foreground">
            Page {page} of {totalPages}
          </span>
          <div className="flex gap-1">
            <PagBtn onClick={() => setPage(1)} disabled={page === 1} label="«" />
            <PagBtn onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} label="‹" />
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
              return (
                <PagBtn key={p} onClick={() => setPage(p)} disabled={false} label={String(p)} active={p === page} />
              );
            })}
            <PagBtn onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages} label="›" />
            <PagBtn onClick={() => setPage(totalPages)} disabled={page === totalPages} label="»" />
          </div>
        </div>
      )}

      {selectedStudent && (
        <StudentDetailModal student={selectedStudent} onClose={() => setSelectedStudent(null)} />
      )}
    </div>
  );
}

function TableRow({ student, index, onView }: { student: Student; index: number; onView: () => void }) {
  const statusConfig = {
    present: { icon: CheckCircle, color: "#10b981", label: "Present" },
    absent: { icon: XCircle, color: "#ef4444", label: "Absent" },
    late: { icon: Clock, color: "#f59e0b", label: "Late" },
  };

  const today = student.todayStatus ? statusConfig[student.todayStatus] : null;
  const colorClass = getAttendanceColor(student.attendancePercentage);

  return (
    <tr
      className="border-b border-border/30 hover:bg-accent/40 transition-colors duration-150 animate-fade-up"
      style={{ animationDelay: `${index * 30}ms`, animationFillMode: "both" }}
    >
      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{student.rollNumber}</td>
      <td className="px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500/30 to-purple-500/30 border border-indigo-500/20 flex items-center justify-center text-xs font-semibold text-indigo-300 shrink-0">
            {student.name.charAt(0)}
          </div>
          <div>
            <div className="font-medium text-foreground text-sm">{student.name}</div>
            <div className="text-xs text-muted-foreground">{student.email}</div>
          </div>
        </div>
      </td>
      <td className="px-4 py-3">
        {today ? (
          <span
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
            style={{ background: `${today.color}18`, color: today.color }}
          >
            <today.icon className="w-3 h-3" />
            {today.label}
          </span>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        )}
      </td>
      <td className={`px-4 py-3 font-bold text-sm ${colorClass}`}>
        {student.attendancePercentage}%
      </td>
      <td className="px-4 py-3 w-32">
        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${getAttendanceBgColor(student.attendancePercentage)}`}
            style={{ width: `${student.attendancePercentage}%` }}
          />
        </div>
      </td>
      <td className="px-4 py-3 text-xs text-muted-foreground">{student.lastAttendance}</td>
      <td className="px-4 py-3 text-xs text-muted-foreground">
        {student.attendedClasses}/{student.totalClasses}
      </td>
      <td className="px-4 py-3 text-right">
        <button
          onClick={onView}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-all border border-primary/20"
        >
          <Eye className="w-3 h-3" /> View
        </button>
      </td>
    </tr>
  );
}

function SortHeader({
  field, current, dir, onClick, label,
}: {
  field: SortField; current: SortField; dir: SortDir; onClick: (f: SortField) => void; label: string;
}) {
  const isActive = current === field;
  return (
    <th
      className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider cursor-pointer hover:text-foreground select-none"
      onClick={() => onClick(field)}
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {isActive ? (
          dir === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />
        ) : (
          <ChevronsUpDown className="w-3 h-3 opacity-30" />
        )}
      </span>
    </th>
  );
}

function FilterSelect({
  label, value, onChange, options,
}: {
  label: string; value: string; onChange: (v: string) => void; options: { value: string; label: string }[];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="px-3 py-2 text-xs bg-secondary border border-border/60 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 cursor-pointer"
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>{o.label}</option>
      ))}
    </select>
  );
}

function PagBtn({
  onClick, disabled, label, active,
}: {
  onClick: () => void; disabled: boolean; label: string; active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-8 h-8 text-xs rounded-lg border transition-all ${
        active
          ? "bg-primary text-primary-foreground border-primary"
          : "border-border/60 text-muted-foreground hover:text-foreground hover:bg-accent disabled:opacity-40 disabled:cursor-not-allowed"
      }`}
    >
      {label}
    </button>
  );
}
