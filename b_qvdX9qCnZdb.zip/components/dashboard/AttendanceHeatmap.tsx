"use client";

import { useMemo } from "react";
import type { AttendanceRecord } from "@/lib/student-data";

interface Props {
  history: AttendanceRecord[];
  compact?: boolean;
}

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function getColor(status: string | null) {
  if (status === "present") return "#10b981";
  if (status === "late") return "#f59e0b";
  if (status === "absent") return "#ef4444";
  return "rgba(255,255,255,0.06)";
}

function getOpacity(status: string | null) {
  if (status === "present") return 0.85;
  if (status === "late") return 0.75;
  if (status === "absent") return 0.5;
  return 1;
}

export default function AttendanceHeatmap({ history, compact = false }: Props) {
  const heatmapData = useMemo(() => {
    const map = new Map<string, string>();
    history.forEach((r) => map.set(r.date, r.status));

    const today = new Date();
    const weeks: { date: string; status: string | null; day: number; isWeekend: boolean }[][] = [];
    let currentWeek: { date: string; status: string | null; day: number; isWeekend: boolean }[] = [];

    const weeksBack = compact ? 12 : 20;
    const startDate = new Date(today);
    startDate.setDate(today.getDate() - (weeksBack * 7 - 1));
    // Align to Sunday
    startDate.setDate(startDate.getDate() - startDate.getDay());

    const cursor = new Date(startDate);
    while (cursor <= today) {
      const dateStr = cursor.toISOString().split("T")[0];
      const day = cursor.getDay();
      const isWeekend = day === 0 || day === 6;
      currentWeek.push({ date: dateStr, status: map.get(dateStr) ?? null, day, isWeekend });
      if (day === 6) { weeks.push(currentWeek); currentWeek = []; }
      cursor.setDate(cursor.getDate() + 1);
    }
    if (currentWeek.length > 0) weeks.push(currentWeek);

    return weeks;
  }, [history, compact]);

  const cellSize = compact ? 10 : 13;
  const gap = compact ? 2 : 3;

  return (
    <div className="overflow-x-auto">
      <div className="inline-block">
        {/* Month labels */}
        <div className="flex mb-1 ml-8">
          {heatmapData.map((week, wi) => {
            const firstDay = week[0];
            if (!firstDay) return null;
            const d = new Date(firstDay.date);
            if (d.getDate() <= 7 || wi === 0) {
              return (
                <div
                  key={wi}
                  className="text-xs text-muted-foreground"
                  style={{ width: cellSize + gap, fontSize: compact ? 9 : 10 }}
                >
                  {MONTHS[d.getMonth()]}
                </div>
              );
            }
            return <div key={wi} style={{ width: cellSize + gap }} />;
          })}
        </div>

        <div className="flex gap-0.5">
          {/* Day labels */}
          <div className="flex flex-col mr-1" style={{ gap }}>
            {DAYS.map((d, i) => (
              <div
                key={d}
                className="text-muted-foreground flex items-center"
                style={{ height: cellSize, fontSize: compact ? 8 : 9, width: compact ? 20 : 24, lineHeight: 1 }}
              >
                {i % 2 === 1 ? d.slice(0, 1) : ""}
              </div>
            ))}
          </div>

          {/* Cells */}
          <div className="flex" style={{ gap }}>
            {heatmapData.map((week, wi) => (
              <div key={wi} className="flex flex-col" style={{ gap }}>
                {DAYS.map((_, di) => {
                  const cell = week.find((c) => c.day === di);
                  if (!cell) return <div key={di} style={{ width: cellSize, height: cellSize }} />;
                  const color = getColor(cell.status);
                  return (
                    <div
                      key={di}
                      title={`${cell.date}: ${cell.status ?? "no data"}`}
                      className="rounded-sm cursor-default transition-opacity hover:opacity-100"
                      style={{
                        width: cellSize,
                        height: cellSize,
                        background: color,
                        opacity: getOpacity(cell.status),
                      }}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 mt-3 ml-8">
          {[
            { color: "#10b981", label: "Present" },
            { color: "#f59e0b", label: "Late" },
            { color: "#ef4444", label: "Absent" },
            { color: "rgba(255,255,255,0.06)", label: "No data" },
          ].map((l) => (
            <div key={l.label} className="flex items-center gap-1">
              <div className="rounded-sm" style={{ width: cellSize - 2, height: cellSize - 2, background: l.color }} />
              <span className="text-muted-foreground" style={{ fontSize: compact ? 9 : 10 }}>{l.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
