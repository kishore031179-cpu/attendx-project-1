"use client";

import { useState, useMemo } from "react";
import {
  CheckSquare, Square, Search, CheckCircle, XCircle, Clock,
  Download, Save, Users, RotateCcw,
} from "lucide-react";
import type { Student, AttendanceStatus } from "@/lib/student-data";
import { getAttendanceColor } from "@/lib/student-data";

interface Props {
  students: Student[];
}

type MarkStatus = AttendanceStatus | null;

export default function BulkAttendance({ students }: Props) {
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  const [marks, setMarks] = useState<Record<number, MarkStatus>>(() => {
    const init: Record<number, MarkStatus> = {};
    students.forEach((s) => { init[s.id] = s.todayStatus ?? "present"; });
    return init;
  });
  const [search, setSearch] = useState("");
  const [saved, setSaved] = useState(false);

  const filtered = students.filter((s) => {
    const q = search.toLowerCase();
    return !q || s.name.toLowerCase().includes(q) || s.rollNumber.toLowerCase().includes(q);
  });

  const mark = (id: number, status: MarkStatus) => setMarks((m) => ({ ...m, [id]: status }));

  const markAll = (status: AttendanceStatus) => {
    const ids = filtered.map((s) => s.id);
    setMarks((m) => {
      const next = { ...m };
      ids.forEach((id) => { next[id] = status; });
      return next;
    });
  };

  const summary = useMemo(() => {
    const present = Object.values(marks).filter((v) => v === "present").length;
    const absent = Object.values(marks).filter((v) => v === "absent").length;
    const late = Object.values(marks).filter((v) => v === "late").length;
    return { present, absent, late };
  }, [marks]);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleExportPDF = async () => {
    const { default: jsPDF } = await import("jspdf");
    const { default: autoTable } = await import("jspdf-autotable");
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text("Attendance Report", 14, 18);
    doc.setFontSize(10);
    doc.text(`Date: ${today}`, 14, 26);
    doc.text(`Class: CS Batch 2024 — Semester IV`, 14, 32);
    doc.text(`Present: ${summary.present}  |  Absent: ${summary.absent}  |  Late: ${summary.late}`, 14, 38);

    autoTable(doc, {
      startY: 44,
      head: [["Roll No.", "Student Name", "Status"]],
      body: students.map((s) => [s.rollNumber, s.name, marks[s.id] ?? "—"]),
      headStyles: { fillColor: [99, 102, 241] },
      alternateRowStyles: { fillColor: [248, 248, 255] },
      styles: { fontSize: 9 },
    });

    doc.save(`attendance_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  return (
    <div className="space-y-5">
      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search students..."
            className="w-full pl-9 pr-4 py-2 text-sm bg-secondary border border-border/60 rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => markAll("present")}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/20 transition-all"
          >
            <CheckCircle className="w-3.5 h-3.5" /> All Present
          </button>
          <button
            onClick={() => markAll("absent")}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 border border-red-500/20 transition-all"
          >
            <XCircle className="w-3.5 h-3.5" /> All Absent
          </button>
          <button
            onClick={() => markAll("late")}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-yellow-500/15 text-yellow-400 hover:bg-yellow-500/25 border border-yellow-500/20 transition-all"
          >
            <Clock className="w-3.5 h-3.5" /> All Late
          </button>
        </div>
      </div>

      {/* Summary bar */}
      <div className="flex items-center gap-4 bg-secondary/60 border border-border/60 rounded-xl px-5 py-3.5">
        <div className="text-xs text-muted-foreground font-medium">{today}</div>
        <div className="flex gap-4 ml-auto">
          <SummaryBadge icon={CheckCircle} color="#10b981" value={summary.present} label="Present" />
          <SummaryBadge icon={XCircle} color="#ef4444" value={summary.absent} label="Absent" />
          <SummaryBadge icon={Clock} color="#f59e0b" value={summary.late} label="Late" />
        </div>
        <div className="flex gap-2 ml-4">
          <button
            onClick={handleSave}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              saved
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-primary text-primary-foreground hover:bg-primary/90"
            }`}
          >
            <Save className="w-3.5 h-3.5" />
            {saved ? "Saved!" : "Save Attendance"}
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-border/60 text-muted-foreground hover:text-foreground hover:bg-accent transition-all"
          >
            <Download className="w-3.5 h-3.5" /> PDF
          </button>
        </div>
      </div>

      {/* Student list */}
      <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-px bg-border/30">
          {filtered.map((student, i) => {
            const status = marks[student.id];
            return (
              <BulkStudentRow
                key={student.id}
                student={student}
                status={status}
                onMark={(s) => mark(student.id, s)}
                index={i}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}

function BulkStudentRow({
  student, status, onMark, index,
}: {
  student: Student; status: MarkStatus; onMark: (s: AttendanceStatus) => void; index: number;
}) {
  const colorClass = getAttendanceColor(student.attendancePercentage);

  return (
    <div
      className="flex items-center gap-3 px-4 py-3 bg-card hover:bg-accent/30 transition-all duration-150 animate-fade-up"
      style={{ animationDelay: `${(index % 20) * 20}ms`, animationFillMode: "both" }}
    >
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/20 flex items-center justify-center text-xs font-semibold text-indigo-300 shrink-0">
        {student.name.charAt(0)}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-xs font-semibold text-foreground truncate">{student.name}</div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-muted-foreground">{student.rollNumber}</span>
          <span className={`text-xs font-medium ${colorClass}`}>{student.attendancePercentage}%</span>
        </div>
      </div>
      <div className="flex gap-1 shrink-0">
        <MarkBtn
          active={status === "present"}
          color="#10b981"
          label="P"
          title="Present"
          onClick={() => onMark("present")}
        />
        <MarkBtn
          active={status === "absent"}
          color="#ef4444"
          label="A"
          title="Absent"
          onClick={() => onMark("absent")}
        />
        <MarkBtn
          active={status === "late"}
          color="#f59e0b"
          label="L"
          title="Late"
          onClick={() => onMark("late")}
        />
      </div>
    </div>
  );
}

function MarkBtn({
  active, color, label, title, onClick,
}: {
  active: boolean; color: string; label: string; title: string; onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="w-7 h-7 text-xs font-bold rounded-lg border transition-all duration-150"
      style={{
        background: active ? `${color}25` : "transparent",
        borderColor: active ? `${color}60` : "rgba(255,255,255,0.1)",
        color: active ? color : "rgba(255,255,255,0.25)",
        transform: active ? "scale(1.05)" : "scale(1)",
      }}
    >
      {label}
    </button>
  );
}

function SummaryBadge({
  icon: Icon, color, value, label,
}: {
  icon: any; color: string; value: number; label: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="w-3.5 h-3.5" style={{ color }} />
      <span className="text-sm font-bold" style={{ color }}>{value}</span>
      <span className="text-xs text-muted-foreground">{label}</span>
    </div>
  );
}
