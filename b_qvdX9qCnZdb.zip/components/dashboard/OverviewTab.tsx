"use client";

import { STUDENTS } from "@/lib/student-data";
import StatCards from "./StatCards";
import AttendanceHeatmap from "./AttendanceHeatmap";
import { AlertTriangle, TrendingDown, Award } from "lucide-react";
import { getAttendanceColor } from "@/lib/student-data";

export default function OverviewTab() {
  const present = STUDENTS.filter((s) => s.todayStatus === "present").length;
  const absent = STUDENTS.filter((s) => s.todayStatus === "absent").length;
  const atRisk = STUDENTS.filter((s) => s.attendancePercentage < 75)
    .sort((a, b) => a.attendancePercentage - b.attendancePercentage)
    .slice(0, 8);
  const topStudents = [...STUDENTS]
    .sort((a, b) => b.attendancePercentage - a.attendancePercentage)
    .slice(0, 5);

  // Use first student's history for class heatmap (aggregate-like)
  const classHistory = STUDENTS[0].history.map((h) => {
    const dateTotal = STUDENTS.filter((s) => s.history.find((r) => r.date === h.date && (r.status === "present" || r.status === "late"))).length;
    return {
      date: h.date,
      status: dateTotal >= 50 ? "present" : dateTotal >= 35 ? "late" : "absent",
    };
  });

  return (
    <div className="space-y-6">
      <StatCards students={STUDENTS} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* At-risk students */}
        <div className="bg-card border border-border/60 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <h3 className="text-sm font-semibold text-foreground">Students At Risk</h3>
            <span className="ml-auto text-xs bg-yellow-500/15 text-yellow-400 border border-yellow-500/20 px-2 py-0.5 rounded-full">
              {atRisk.length}
            </span>
          </div>
          <div className="space-y-2">
            {atRisk.map((s) => (
              <div key={s.id} className="flex items-center gap-3 py-2 px-3 rounded-lg bg-secondary/60 border border-border/40 hover:bg-accent/40 transition-all">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-red-500/20 to-orange-500/20 border border-red-500/20 flex items-center justify-center text-xs font-bold text-red-400 shrink-0">
                  {s.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-foreground truncate">{s.name}</div>
                  <div className="text-xs font-mono text-muted-foreground">{s.rollNumber}</div>
                </div>
                <span className={`text-sm font-bold ${getAttendanceColor(s.attendancePercentage)}`}>
                  {s.attendancePercentage}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top performers */}
        <div className="bg-card border border-border/60 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-foreground">Top Performers</h3>
          </div>
          <div className="space-y-2">
            {topStudents.map((s, i) => (
              <div key={s.id} className="flex items-center gap-3 py-2 px-3 rounded-lg bg-secondary/60 border border-border/40">
                <span className="text-xs font-bold text-muted-foreground w-5">#{i + 1}</span>
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/20 flex items-center justify-center text-xs font-bold text-emerald-400 shrink-0">
                  {s.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-foreground truncate">{s.name}</div>
                  <div className="text-xs font-mono text-muted-foreground">{s.rollNumber}</div>
                </div>
                <span className="text-sm font-bold text-emerald-400">{s.attendancePercentage}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick stats card */}
        <div className="bg-card border border-border/60 rounded-xl p-5 flex flex-col gap-4">
          <h3 className="text-sm font-semibold text-foreground">Today&apos;s Summary</h3>
          <div className="space-y-3">
            {[
              { label: "Total Students", value: 65, color: "#6366f1" },
              { label: "Present", value: present, color: "#10b981" },
              { label: "Absent", value: absent, color: "#ef4444" },
              { label: "Late", value: STUDENTS.filter((s) => s.todayStatus === "late").length, color: "#f59e0b" },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className="font-semibold" style={{ color: item.color }}>{item.value}</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${(item.value / 65) * 100}%`, background: item.color }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-auto p-3 bg-secondary/50 border border-border/40 rounded-xl">
            <div className="text-xs text-muted-foreground mb-1">Semester Progress</div>
            <div className="flex items-end justify-between">
              <div className="text-2xl font-bold text-foreground">60</div>
              <div className="text-xs text-muted-foreground">classes conducted</div>
            </div>
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden mt-2">
              <div className="h-full rounded-full bg-primary w-3/4" />
            </div>
            <div className="text-xs text-muted-foreground mt-1">75% of semester complete</div>
          </div>
        </div>
      </div>

      {/* Class heatmap */}
      <div className="bg-card border border-border/60 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">Class Attendance Calendar</h3>
        <AttendanceHeatmap history={classHistory as any} />
      </div>
    </div>
  );
}
