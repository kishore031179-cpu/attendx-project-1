"use client";

import { useState } from "react";
import { STUDENTS } from "@/lib/student-data";
import Header from "@/components/dashboard/Header";
import OverviewTab from "@/components/dashboard/OverviewTab";
import AttendanceTable from "@/components/dashboard/AttendanceTable";
import StudentCards from "@/components/dashboard/StudentCards";
import AnalyticsDashboard from "@/components/dashboard/AnalyticsDashboard";
import BulkAttendance from "@/components/dashboard/BulkAttendance";

type Tab = "overview" | "students" | "analytics" | "attendance";

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<Tab>("overview");
  const [viewMode, setViewMode] = useState<"table" | "cards">("table");

  const totalPresent = STUDENTS.filter((s) => s.todayStatus === "present").length;
  const totalAbsent = STUDENTS.filter((s) => s.todayStatus === "absent").length;

  return (
    <div className="min-h-screen bg-background">
      <Header
        activeTab={activeTab}
        onTabChange={(t) => setActiveTab(t as Tab)}
        totalPresent={totalPresent}
        totalAbsent={totalAbsent}
      />

      <main className="max-w-screen-2xl mx-auto px-6 py-6">
        {activeTab === "overview" && (
          <section className="animate-fade-up">
            <OverviewTab />
          </section>
        )}

        {activeTab === "students" && (
          <section className="animate-fade-up">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-lg font-bold text-foreground">Student Roster</h2>
                <p className="text-sm text-muted-foreground">65 students · CS Batch 2024</p>
              </div>
              <div className="flex bg-secondary border border-border/60 rounded-lg p-0.5">
                <button
                  onClick={() => setViewMode("table")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                    viewMode === "table" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Table
                </button>
                <button
                  onClick={() => setViewMode("cards")}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${
                    viewMode === "cards" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  Cards
                </button>
              </div>
            </div>
            {viewMode === "table" ? (
              <AttendanceTable students={STUDENTS} />
            ) : (
              <StudentCards students={STUDENTS} />
            )}
          </section>
        )}

        {activeTab === "analytics" && (
          <section className="animate-fade-up">
            <div className="mb-5">
              <h2 className="text-lg font-bold text-foreground">Analytics Dashboard</h2>
              <p className="text-sm text-muted-foreground">Attendance trends and insights for CS Batch 2024</p>
            </div>
            <AnalyticsDashboard students={STUDENTS} />
          </section>
        )}

        {activeTab === "attendance" && (
          <section className="animate-fade-up">
            <div className="mb-5">
              <h2 className="text-lg font-bold text-foreground">Mark Attendance</h2>
              <p className="text-sm text-muted-foreground">Bulk attendance marking with PDF export</p>
            </div>
            <BulkAttendance students={STUDENTS} />
          </section>
        )}
      </main>
    </div>
  );
}
